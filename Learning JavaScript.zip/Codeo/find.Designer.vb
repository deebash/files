﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class find
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.findTxt = New System.Windows.Forms.TextBox()
        Me.findBackBtn = New System.Windows.Forms.Button()
        Me.findNextBtn = New System.Windows.Forms.Button()
        Me.replaceAllBtn = New System.Windows.Forms.Button()
        Me.replaceBtn = New System.Windows.Forms.Button()
        Me.replaceTxt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.skipBtn = New System.Windows.Forms.Button()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(32, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Find : "
        '
        'findTxt
        '
        Me.findTxt.Location = New System.Drawing.Point(64, 14)
        Me.findTxt.Name = "findTxt"
        Me.findTxt.Size = New System.Drawing.Size(214, 20)
        Me.findTxt.TabIndex = 1
        '
        'findBackBtn
        '
        Me.findBackBtn.Location = New System.Drawing.Point(284, 11)
        Me.findBackBtn.Name = "findBackBtn"
        Me.findBackBtn.Size = New System.Drawing.Size(60, 25)
        Me.findBackBtn.TabIndex = 2
        Me.findBackBtn.Text = "<< Find"
        Me.findBackBtn.UseVisualStyleBackColor = True
        '
        'findNextBtn
        '
        Me.findNextBtn.Location = New System.Drawing.Point(350, 11)
        Me.findNextBtn.Name = "findNextBtn"
        Me.findNextBtn.Size = New System.Drawing.Size(60, 25)
        Me.findNextBtn.TabIndex = 3
        Me.findNextBtn.Text = "Find >>"
        Me.findNextBtn.UseVisualStyleBackColor = True
        '
        'replaceAllBtn
        '
        Me.replaceAllBtn.Location = New System.Drawing.Point(284, 73)
        Me.replaceAllBtn.Name = "replaceAllBtn"
        Me.replaceAllBtn.Size = New System.Drawing.Size(126, 25)
        Me.replaceAllBtn.TabIndex = 7
        Me.replaceAllBtn.Text = "Replace All"
        Me.replaceAllBtn.UseVisualStyleBackColor = True
        '
        'replaceBtn
        '
        Me.replaceBtn.Location = New System.Drawing.Point(284, 42)
        Me.replaceBtn.Name = "replaceBtn"
        Me.replaceBtn.Size = New System.Drawing.Size(60, 25)
        Me.replaceBtn.TabIndex = 6
        Me.replaceBtn.Text = "Replace"
        Me.replaceBtn.UseVisualStyleBackColor = True
        '
        'replaceTxt
        '
        Me.replaceTxt.Location = New System.Drawing.Point(64, 45)
        Me.replaceTxt.Name = "replaceTxt"
        Me.replaceTxt.Size = New System.Drawing.Size(214, 20)
        Me.replaceTxt.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Replace : "
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(15, 78)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(82, 17)
        Me.CheckBox1.TabIndex = 8
        Me.CheckBox1.Text = "Match case"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(103, 78)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(89, 17)
        Me.CheckBox2.TabIndex = 9
        Me.CheckBox2.Text = "Wrap Around"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'skipBtn
        '
        Me.skipBtn.Location = New System.Drawing.Point(350, 42)
        Me.skipBtn.Name = "skipBtn"
        Me.skipBtn.Size = New System.Drawing.Size(60, 25)
        Me.skipBtn.TabIndex = 10
        Me.skipBtn.Text = "Skip >"
        Me.skipBtn.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(198, 78)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(80, 17)
        Me.CheckBox3.TabIndex = 11
        Me.CheckBox3.Text = "In selection"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'find
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(416, 109)
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.skipBtn)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.replaceAllBtn)
        Me.Controls.Add(Me.replaceBtn)
        Me.Controls.Add(Me.replaceTxt)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.findNextBtn)
        Me.Controls.Add(Me.findBackBtn)
        Me.Controls.Add(Me.findTxt)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "find"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Find"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents findTxt As System.Windows.Forms.TextBox
    Friend WithEvents findBackBtn As System.Windows.Forms.Button
    Friend WithEvents findNextBtn As System.Windows.Forms.Button
    Friend WithEvents replaceAllBtn As System.Windows.Forms.Button
    Friend WithEvents replaceBtn As System.Windows.Forms.Button
    Friend WithEvents replaceTxt As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents skipBtn As System.Windows.Forms.Button
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
End Class
