﻿Public Class Form1

    Private Sub Form1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.DoubleClick
        main.Show()
        Me.Hide()
    End Sub
End Class
