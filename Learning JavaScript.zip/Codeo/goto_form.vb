﻿Public Class goto_form
    Dim editor As ICSharpCode.TextEditor.TextEditorControl = main.KryptonNavigator1.SelectedPage.Controls(0)

    Private Sub goto_form_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then
            editor.ActiveTextAreaControl.Caret.Line = TextBox1.Text - 1
            Me.Close()
        End If
    End Sub

    Private Sub goto_form_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress

    End Sub

    Private Sub goto_form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label2.Text = "Right now: " & editor.ActiveTextAreaControl.Caret.Line & "  Total Lines: " & editor.ActiveTextAreaControl.Document.TotalNumberOfLines
        TextBox1.Select()
        Button1.Focus()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        moveCaret()
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            moveCaret()
            Me.Close()
        End If
    End Sub

    Private Sub moveCaret()
        If (CheckBox1.Checked) Then
            editor.ActiveTextAreaControl.Caret.Line = TextBox1.Text - 1
        Else
            editor.ActiveTextAreaControl.Caret.Line = TextBox1.Text - 1
            editor.ActiveTextAreaControl.Caret.Column = 0
        End If
    End Sub
    
End Class