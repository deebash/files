﻿Imports System.IO
Imports System.Text
Imports System.Net
Imports Newtonsoft.Json
Imports System.Threading
Imports System.Drawing
Public Class Form1
    Dim imagePath
    Dim curFileName
    Dim totalFiles
    Dim curFile
    Dim progressPercent = 0
    Dim MyBitmaps As New List(Of Bitmap)
    Dim mousePath As New System.Drawing.Drawing2D.GraphicsPath() 'declare a new Graphic path to follow the mouse movement
    Dim myAlpha As Integer = 100 ' declare a Alpha variable
    Dim myUserColor As New Color() 'this is a color the user selects
    Dim myPenWidth As Single = 5 'set pen width variable
    Dim importMode = 0
    Dim DrawingImg As Bitmap
    Dim DrawingGraphics As Graphics


    Public Function GetLaTex(ByVal Base64String)
        Dim postData As String = "{""url"": ""data:image/png;base64," & Base64String & """}"
        'Dim postData As String = "{""url"": ""data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAacAAABFCAIAAABhdr7yAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABQRSURBVHhe7Z2JVxRXFofnPxmNxkxmxon7Brjgjnvcd9wQl6BRwQU3XImKK+K+a4yiopCAaFQmiqISXBI3xMSAHqPJiRqNo0c4zNf9KjU11Vt12622fb9Tx8N7XVX96t13f/fe6ur2L5WC/8g7fiL/1CmtIQjCW4monj95+PBhRUWF1hAE4a1EVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVE8QhNBCVM8lZwsKpsQnTE2YvHH9hlUrViROnfb40WPtNUEQghZRPee8fPky61Dmzu07Ips2u3vnzg+3brVt2erHH3/UXhYEIWgR1XNJeXn57BkzF85fUFFRkZOd3btHzydPnmivCYIQtIjquQSNQ+kOZ+eQ902Oj1+WsvTokSO/P5YiVxCCG1E9l9y+fbtLh46lpaUvXryYNGHilPiEgxkZJIDay4IgBCeiei6hsH3+n+f630+fPlV/C4IQ1IjqCYIQWojqCYIQWojqCYIQWojqCYIQWojqVX6+c+f7Vd+r9tcqf6v+fnjjJhFNwpxu9WrV/qBadXYzbvSk79mrnUgQhGBAVK/ywf0H3Tp3QcJq1ax5Ov+01uuC8vLyXx48+Hde3sJ58xvUrcdR/fv0lYf4BCGIENWzUXj+fP3adZCwTlFRd+/e1Xo98ccff2zeuKlJg4anTp7UugRBeOt5HapHfnQ6P//+/fta21euX7v23eXLWsOvVFRUbN2yRRWwU+IT9Mf0rJB3Ii9l8eIXL15obde8fPnS6f+W+/jRY05i5Qweefjwob9OZR1/2ddI4GwtCL6r3s8//7xk0aLEqdPYkmbOmjM7iW1GYiLNRcnJlI1qN/x8zxdfbN282fitBtzSurLoOz99+nRuUtK5s2dVv38hcRsfF6du1e3+/HOn8uQUrutwdo5Hn0fa4saMzTt+Qmv/yZMnT5i3bwu/1dp2GIxxuhx59OhR8oKFA/r2O5iRoXXZYdj79qavX7fO/eFW+O2335YvXZYwaRIbI6SiZ/KXLkkpLCw0To7Jvvy7Pz19aHQ0hzx79kztYx39wgNq69fAr7/8EqBf6PHKd7COPF3vyCvlemQWPbp1i42JYbGqHqY48+ChzlEdbt++rXouXbw4OT7e+L19nGHI4MH4ErmP1uUado4eOIj8S+18q6Rk7KjRLCn1qn8pLS1t16o1wteoXn2GrfX6AxYfSvphjRoogtZlh35qZCTDqCPFxcUMICc7W2u74E5ZWasWkQiu1v4TXCJxylS/FN1Ys3+fPpMmTFTJI3p0Ov90ZNNma9PSdFV1tC87Txg3fmrCZCv2NXLj+nUuPDfnsGoG1NYB4vfHjzEcAalZWPiR3Fyt1zLMWFZm5oihw1iKWtf/45XvABVMZLPmJCha2wLXrl4dEzvqy6wsrf0u8kqq98OtW2ENG23bulVr28HrUleuVLkeDoBLZB3KVC/poIlkK1rDEz/99JMeNnG2eXPmrF+7VjX9DrnYR//4J8LXu0fPX3/9Vet9ZcpKy8iL69WqvWHdeq3LDot7UP8B6JfWtvP8+fObxTc9Luv8U6daNm/h9MevuIqYYcNfPcgzbHxm7xd7tLbdLcnl27dp68a+zFu3zl1IALW2Zbjwkpsl+oUH2taBgGvPO5FX9G1Ri4imuYe9UD28ZteOnRFNwhC1q1euaL3O8Mp3SNhNq8sN58+dY9mzqEhcLKpqkPJKqkeiUb92Hb06Ux9lYj/yGuVyRG+SBb3a9QtnCwo4p3XDewWetnL58upVqiJ88+fOVTnOK8IC+mL3boq1Ni1bLpy/QM+SgFCcNHOWscci5IZrVqdR4TqVNianb6/er14eHj92jKj2/Xffa217BUom0qdnLxWHnNr38qVL+LzxKJ8JqK0DB3GajNii6pEmr16V2rBevbixY9/IDziy/I59/XWHdu07RUWdOHbcWHa8q/iuekzWouRkJksteqLcvr3pyASzRuWr9tm9a9enceOM2nH//n12u1BUpLXdglORaJBRam079+7di2rbDtfS2v4Gfx4WPQTV+3uND/yS51+8cIHgyZz07PYx1aIeRUltRo+MPbB/v2oCU/fd5ctkSR5LEo6NjYlh/rECZ+Yk5Hf6PPMW8RMnknGrpiPqyRv38ZzBrFi2rGunzuQLek/6nr3hjZvoz/c42heIed27duUozs8bMTaPWTNnYE9yRtO9sMDZmvKZ3Grj+g1cix51kFfGQP9XX36panYGRu62eeOmUydP3r17l2vh6jzew7WoekwLVqhfp+70adOsFKFe+Q4nP5iRYbw6RzBQxoEDDJUUr/D8ea3XNSQ0uTmHT+fncyApJ7GcTV8eQYTvqme/6dOXsE+gyMnOnhKfYCyFgOmekZi4dEmKHj0wG9NE/v9xl64saNXpCgyGWBScOdOjWzfjOsPhBw8YaHovBcagNkQ4XG2YSh+MG27cuNEsLBzhax4eUVxcrPX6BPnv1s2bWRkMGzGlfmHpqJeIFl06dCwsLFRNoMT4+uhRqmCPN8WYPcpMpp365fOdO0m6CT9Gf9iyaROyaNIjLEIgYQCYDFnkVWpYV5KkbiENHzKUXB6TZWVmkqhS3uoT4mhfYNjqZ/dRDTSC3IEzkMu4mXbGg5gyD4jsrOkzjBfuxtY+w0i4ltgRI9AmLoHZI8zQycyg4IQo9kECmB8yLwaD3hGu2J/LIdXF7Wm6Lxs9qt4vDx4wS+hdyuLFFjNZr3zn7p0727dtK7lZMrBf/6NHjmi9BjD9zu07mjRoiHWuX7um9XqCU7FEWcaLP/sMuUQBtm3dOnH8p/qSDhZ8Vz3WBLM2c/p01gEzyPxiEu01OyzZodHRhFOtXVmZ/dVXTDHhFI91HzB5laDKGU5+8w0LyHhzl4U47pNPVq1YobUN4MPRAweRHbjaONBiaMIxyPUQPpbFqzyEzNI/c/oMfzDsyfHxKLi+yslh0VYUVjVZQ3ggiduEceMJ/kbnd4SQ0LJ5C/49lHGQA3FC0hPjZ6ZMcq/uPfRPmRRkUkghbkM4WbJo0bKUpRSwrj73sN3Ua9osdeUqalU26uXlS5dx+LWrV9UOjvYFNJRED2dgAKwQhkS+7F4jCGwkegjQvDlzxo4abVRqN7b2GUbFSlBawHvxjqNGjmTaPxk9Rr9DjQii1AmTJuHPDGzO7CSUTq0cpoXV6/7DIo+qd/XKlRYRTfv17m09jbXuO0wacQLhwxadozqYPkBTEJO4Xvx3/759ptDoCg7BJTktoRpLqaNwE/JEvbYLFnxXPXVTTyXGTDSBiAjG3ywO/QYfySAzZdvbDtkNLjomdhQ5gnuvxl1VsbNmdVrfXr05SvUDq5A4SWmgtQMDRsW0qF71KlXXrVnjJlVxAx4SM2y4euxjwbx5LJfWkZF6LUPSxNLXP+zmHZlAmnSSi6lOVzCkerVqr1+3zlWYPZKby9s5XY7kbv379MF2HK7qOKeom3pXvv/fnXVGSDaEOZRwO9oX0Me6H9Ui/lu/ic6C4cyYmDOnpa7Weu0EwtZkdhFNwvQ4ylUAw0YCjM8VIdbU8hTCjGFuUpJeyOP2pNXuDWSlwuW02AgJIwhRM3pcYNZ9hzOrD74pbsIbNeZf1e8IySCKj5WpDIwh0ylqfaLXhFu1KhhzyuIlDIkJVPsECz6qHjNLltuudRv9TjYOxiwo+VNfb2AuSABNXoGrNw0Lw8xa2y2cAdVQ/3OF1mVX2PFxcZQGWjtgsHR6fty9Vs2aeSfytC5vYJyEXBaW1q6s3LRhY6N69XWZoxiPbNZcbyp2bNuOWrlPSJmW0SNjJ306gZKQbMv0rJ+CINy1U2fHLBX3ZqGTESMxRGmSdKfLnQkns+vWuYtxJBg9aeYszKcUzal90ZSO7dtv3bIFw/Evh2gveEJlvmSvWttOIGyN1hNXTN/AyT91ijBgzOBsQb1OXQpeLgHV0x/fQfX0VNEVFu/rKdQ9HFyJd3Q/XV75DuzetcvjWgKmgtDSuH4Dcn/TfVVHWNKMVkVTdmYVmR7hCAp8VD3CzoC+/ag+1FLQIQjs2rFTGY+XyKJNz2qw5pg1LHGhqMhjiMAeJEemJ9c4LVWn6bQKlSiRoLnaKL6sP/+FKrFoMLPHOOwUihfqEeOxGQcOkAfpRQ2ZYNuWrW5cv66aoGaVxUdt4ubxhXv37qEsuTmHEQXW66zpM5hJQrrRFqx4EjpTJsi0YxGKGsRl/ty5XCDa5NSBkUL0dNrkKbyF1mV/Lp00h9iuhNLRvuzMIYlTpvIHFRmzRy2G7qsiwD1U6G1atjTdsXJja59hYGQ3xtu1zN6NGzcQFONKS9+zl5iEjQKtegocZ8igQRzFejPa0YhXvoMJ4ifa/tsDowXdwGlJL9A+ApsrexntS7OwsLBVi0imjtI7uIpcH1VPPalHMNfadjD22FGj9YwahycBnjl9uh7BcMLBAwaSoVBf4Hv0Y2BOgos6jXJE4ObhEaaP8ynKenXv4cMjoF6BuyJADNXiojGBQHy2MNm0esgZKUv1zJFQSbZlrJWQIaqqom+LThw7rm6Sch7qO9MN0zOnzyAQSDxjwxtRScKDmk9tj8pKOqcmTHY6q4DEkC268RwMhAcan7nDK6hbUVvdHI72ZZ+e3T5WP0KTefBQv969iTE0VaRxei0KzrBg3rzYmBjTkEy25sKZVVcfv1iE8pxUV/+AhXR43950/l2UnDx7xkylOMg6E5u6chUDgzmzk8isddWjLHWveir66o9bW4e5jRs7liTdlIqCt76jbupReGltazDha1anuRo80kb1gy7zN7OXlrqaqInR6WECKfsIpU7t+7bhter9Yf/KfZ+evUidiMOsY7YZiYlDBg/+598+xGbG/ILFQcah3zzCS1lbTM3G9RvU7S0ma1D/Afiwo5mBpcnhxpt6cKukBN9DYbV2AGDApLHESdOnAVbgGikbiYF1/vXRgf37lWvxL3kEV1q9SlWuSCkdi3X6tGnGW/WsG5Xa7E9PV/5/6eJF6iw9uiqoKVhtjI3TsuB4lfzaWEpz7MjhI3Bmre0ArouCqLGZwHycn0G+X/U9ZAjjYq/J8fEMjEqTJa7tZ8dkXxIo8iCVvZICcDj17/Fjx9QbOb0WBWdgRa1NS9Paf2K0NSdZv3ZtzQ//bsr9fQBx+TRuHCU82TdLkXehk6W4dElK8oKFZOjIXOrKlcww8rdpw0YCADGeHi4hYdKkD2vUoLQnMqmzGUHfOQlp8gfVqiNeJInWPyF1j7e+Q0kR3qjx9/54alKHNUayr18RWTOxgdCoyhf0jqDurc6+EXzM9SxCsoNhTIZnZRjXvVIEp8ENT8PSJudkperlRiBAMnB13trk4YGAvI+cy3hnjesy5TIs7oMZGcbrJQzoQgOkpcYzAOkAeZZ+wz5wmOyLWY2TRjLr8VoUuBMFZsEZ24fdRhxtfe3qVSoArfFqMFTHD0OZSebNTRb8ZrHoO0Do7dKxk38LT+K06cYfTdPaCwoCq3pYhcRw5fLlJuUyQkQlJ9ITOppfHz2Kt1DutY6MND08yW7IxMlvvtHa/ga7bt28uXvXrgHNJXVUUnn+3Dmt7Ywfbt0ipXIzgY4w51SCTgsf/2LFvkZM11JWWvbvPNsvxJCrkuuZnlxzamvSZBaG1gha7pSVrVuzZlnKUqcbdatJXFxh8h0mlrVEYECJYkeMIJl1ZRd2oBQwva++kdUabze/ewRW9YCIOm3yFDeTeDo//2xBgdawf4e0eXgE9RdBnpLHVA19mZVF9ueYLPgLIic1mlc/PYC45OYcVkWHD7BMk2bN1heuCRLe/fv2eXVy9JryzWn8DwQe7atjuhbmjQsfFj2EFG9A337GNaBwtDVigZMHzvqvjXv37qlvhjhuFNTokTGXd4PJd0i9O0VFcZId27aPiR2lbqc6BVswvbyX8a31DdlVVf+7SsBVD4qLi5cuSXH1DLp65EVr2AtM0oHt27Y5foiJa5HCBO7TosLCwnat2/DuWtsa586enTM7iairtb2Ea886lJm+Z6/T1AwPtxj2FXgLU62+YPDacG9fHcdrocDkwvWPO4w4tTUF8ltbe74RTL4Dly9dwnfIiGWi3PA6VA/IZXzWBR1sHDhbEty6dOxEBHZVFDhCHpqVmRneuInTx9+9gozJLwUpMdwrlfQXfrGvkYDaWghxXpPqveVQGgweMNDiTyKzD3ko1UGXDh2r/bVKZLPm1r+HIAjCG0dUz5anjI+Lq16lavPwiFYtIl1tTcPCatf8V433qunPPKvN9IV5QRDeckT1bDfmhgyyfUPLh21odHRQPJYpCIKOqJ4gCKGFqJ4gCKGFqJ4gCKGFqJ4gCKGFqJ6NFy9epKWutv3WxZ07WpcnysvL807kvduPsAvCO4monsaR3Nxe3XtY/CZQyc0SVLJDu/aHHf47WkEQ3nJE9WxUVFQsSk6ekZho/QsSz/9j+zUnUT1BCDpE9Ww8e/ZsUP8B+/amk/ElzZyVvGDh748fr1uzZm5SkmnbuH6DygdF9QQhSBHVs1FaWtosLByxu1BUdLagAC1D2nZs2276BR62XTt2qt9HEdUThCBFVM/G0SNH6n5UKzYmJi11tcUvvYvqCUKQIqpnu6mXsnjxjMTEkpslbVu2unjhwqmTJ9V/s236yi1bp6go9QO8onqCEKSI6tl+0S9m2PBDGQcf3H8wYugwFNDjr4reKStLXbmqSYOGpIc52dny6wOCEESI6tkgcVM/q1deXh6M/w+AIAjWEdUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCG0ENUTBCGUqKz8L92JI9GkvLwZAAAAAElFTkSuQmCC""}"

        Dim tempCookies As New CookieContainer
        Dim encoding As New UTF8Encoding
        Dim byteData As Byte() = encoding.GetBytes(postData)
        Dim postReq As HttpWebRequest = DirectCast(WebRequest.Create("https://api.mathpix.com/v3/latex"), HttpWebRequest)
        postReq.Method = "POST"
        postReq.ContentType = "application/json"
        postReq.Headers.Add("app_id", "canvas-drawing")
        postReq.Headers.Add("app_key", "letswastetimetogether")

        Dim postreqstream As Stream = postReq.GetRequestStream()
        postreqstream.Write(byteData, 0, byteData.Length)
        postreqstream.Close()
        Dim postresponse As HttpWebResponse
        Try
            postresponse = DirectCast(postReq.GetResponse(), HttpWebResponse)
            Dim postreqreader As New StreamReader(postresponse.GetResponseStream())
            Dim thepage As String = postreqreader.ReadToEnd

            Return thepage
        Catch ex As WebException
            Return ex.ToString
        End Try

    End Function
    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.AllowDrop = True
        PictureBox2.Image = New Bitmap(PictureBox2.Width, PictureBox2.Height)
        DrawingImg = New Bitmap(PictureBox2.Width, PictureBox2.Height)
        DrawingGraphics = Graphics.FromImage(DrawingImg)
        DrawingGraphics.Clear(Color.White)
    End Sub
    Private Sub Label1_DragDrop1(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Label1.DragDrop
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        For Each path In files
            Label1.Visible = False
            PictureBox1.Load(path)
            imagePath = path
        Next
    End Sub
    Private Sub Label1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Label1.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If importMode = 0 Then
            ImageList1.Images.Add(PictureBox1.Image)
            MyBitmaps.Add(PictureBox1.Image)
            Dim Filename As String = imagePath
            Dim FileInfo As New FileInfo(Filename)
            DataGridView1.Rows.Add(ImageList1.Images.Count, True, ImageList1.Images(ImageList1.Images.Count - 1), FileInfo.Name, FileInfo.Name, FileInfo.Directory, "", "")
            FileInfo = Nothing
        ElseIf importMode = 1 Then
            Dim imagePath = "C:\Users\dd1767\Desktop\Assemblies" & "\" & "Drawing_" & System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") & ".jpg"
            'PictureBox2.Image.Save(imagePath)
            DrawingImg.Save(imagePath)
            ImageList1.Images.Add(DrawingImg)
            MyBitmaps.Add(DrawingImg)
            Dim Filename As String = imagePath
            Dim FileInfo As New FileInfo(Filename)
            DataGridView1.Rows.Add(ImageList1.Images.Count, True, ImageList1.Images(ImageList1.Images.Count - 1), FileInfo.Name, FileInfo.Name, FileInfo.Directory, "", "")
            FileInfo = Nothing
        End If


    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim j = 0
        For i = 0 To DataGridView1.RowCount - 1
            If (DataGridView1.Rows(i).Cells("col_check").Value = True) Then
                j = j + 1
            End If
        Next
        totalFiles = j
        progressPercent = 0
        pb1.Value = 0
        BackgroundWorker1.RunWorkerAsync()
    End Sub
    Public Function showGallery()
        For Each bitmp In MyBitmaps
            Dim pb As New PictureBox
            pb.Width = 100 'or whatever
            pb.Height = 100
            pb.Top = 0 'or whatever
            pb.Left = 0
            pb.BackColor = Color.White
            pb.SizeMode = PictureBoxSizeMode.Zoom
            pb.Image = bitmp
            pb.Tag = ImageList1.Images.Count - 1
            FlowLayoutPanel1.Controls.Add(pb)
        Next

    End Function
    Public Function sendLog(ByVal logstring)
        Dim time = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
        logText.Text = logText.Text & time & " - " & logstring & vbCrLf
    End Function
    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        'sendLog("Conversion begins...")
        BackgroundWorker1.ReportProgress(1)
        For i = 0 To DataGridView1.RowCount - 1
            curFile = i + 1
            If (DataGridView1.Rows(i).Cells("col_check").Value = True) Then
                Dim filePath = DataGridView1.Rows(i).Cells("col_path").Value
                Dim fileName = DataGridView1.Rows(i).Cells("col_filename").Value
                Dim imageIndex = DataGridView1.Rows(i).Cells("col_num").Value
                Dim fullName = DataGridView1.Rows(i).Cells("col_path").Value.ToString & "\" & DataGridView1.Rows(i).Cells("col_filename").Value.ToString
                curFileName = fileName
                BackgroundWorker1.ReportProgress(2)
                Dim a As New Base64Codec
                PictureBox1.Invalidate()
                PictureBox1.Load(fullName)
                Dim Base64str = a.ConvertImageToBase64(PictureBox1.Image)
                ' rtb1.Text = "{""url"": ""data:image/png;base64," & Base64str & """}"
                BackgroundWorker1.ReportProgress(3)
                BackgroundWorker1.ReportProgress(4)
                Thread.Sleep(1000)
                Dim updateTxtBoxDel As UpdateTextBoxDelegate = New UpdateTextBoxDelegate(AddressOf UpdateRTB)
                Me.Invoke(updateTxtBoxDel, GetLaTex(Base64str))
                BackgroundWorker1.ReportProgress(5)
            End If
        Next
        BackgroundWorker1.ReportProgress(6)
    End Sub
    Delegate Sub UpdateTextBoxDelegate(ByVal myString As String)
    Public Sub UpdateRTB(ByVal myString As String)
        Dim myObject = JsonConvert.DeserializeObject(myString)
        myString = myObject("latex").ToString
        rtb1.Text = myString
        Dim appPath As String = My.Application.Info.DirectoryPath
        DataGridView1.Rows(curFile - 1).Cells("col_status").Value = "Received"
        DataGridView1.Rows(curFile - 1).Cells("col_result").Value = myString
        htmlBox1.Text = "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>MathJax example</title><script type='text/javascript' async src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML'></script></head><body><p>"
        'htmlBox1.Text = "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>MathJax example</title><script type='text/javascript' async src='" & appPath & "'></script></head><body><p>"
        htmlBox1.Text = htmlBox1.Text & "$$" & myString & "$$</p></body></html>"
        'MsgBox(DataGridView1.Rows(curFile - 1).Cells("col_path").Value.ToString)
        Dim filename = ""
        If (outputFile0.Checked = True) Then
            filename = GetFileName(DataGridView1.Rows(curFile - 1).Cells("col_filename").Value)
        Else
            filename = GetFileName(DataGridView1.Rows(curFile - 1).Cells("col_name").Value)
        End If
        File.WriteAllText(outputPath.Text & "\" & filename & ".html", htmlBox1.Text)
    End Sub
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        Dim i = e.ProgressPercentage
        Select Case i
            Case 1
                sendLog("Conversion begins...")
            Case 2
                sendLog("Converting " & curFileName)
                DataGridView1.Rows(curFile - 1).Cells("col_status").Value = "Converting..."
                progressPercent = progressPercent + 25
            Case 3
                sendLog("Base64 ready for " & curFileName)
                progressPercent = progressPercent + 25
            Case 4
                sendLog("Contacting MathPix...")
                progressPercent = progressPercent + 25
            Case 5
                sendLog("Received LaTex for " & curFileName)
                progressPercent = progressPercent + 25
            Case 6
                sendLog("Conversion completed.")
                'progressPercent = 0
            Case Else
                sendLog("Sending to API " & curFileName)
        End Select
        pb1.Value = progressPercent / (totalFiles)
        statusTxt.Text = "Converting " & curFile & " of " & totalFiles & " - " & pb1.Value & "%"

    End Sub
    Public Function GetFileName(ByVal filepath As String) As String

        Dim slashindex As Integer = filepath.LastIndexOf("\")
        Dim dotindex As Integer = filepath.LastIndexOf(".")

        GetFileName = filepath.Substring(slashindex + 1, dotindex - slashindex - 1)
    End Function

    Private Sub FlowLayoutPanel1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles FlowLayoutPanel1.DragDrop
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        For Each path In files
            Dim pb As New PictureBox
            pb.Width = 100 'or whatever
            pb.Height = 100
            pb.Top = 0 'or whatever
            pb.Left = 0
            pb.BorderStyle = BorderStyle.Fixed3D
            pb.BackColor = Color.White
            pb.SizeMode = PictureBoxSizeMode.Zoom
            pb.Load(path)
            pb.Tag = ImageList1.Images.Count - 1
            FlowLayoutPanel1.Controls.Add(pb)
        Next
    End Sub

    Private Sub FlowLayoutPanel1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles FlowLayoutPanel1.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub DataGridView1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragDrop
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        Dim i = 0
        For Each path In files
            PictureBox1.Load(path)
            ImageList1.Images.Add(PictureBox1.Image)
            MyBitmaps.Add(PictureBox1.Image)
            Dim Filename As String = path
            Dim FileInfo As New FileInfo(Filename)
            DataGridView1.Rows.Add(ImageList1.Images.Count, True, ImageList1.Images(i), GetFileName(FileInfo.Name), FileInfo.Name, FileInfo.Directory, "", "")
            FileInfo = Nothing
            i = i + 1
        Next
    End Sub

    Private Sub DataGridView1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles DataGridView1.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub DataGridView1_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.RowHeaderMouseClick
        Label1.Visible = False
        rtb1.Text = DataGridView1.Rows(e.RowIndex).Cells("col_result").Value
        PictureBox1.Image = MyBitmaps(e.RowIndex)
        Dim fullName = outputPath.Text & "\" & GetFileName(DataGridView1.Rows(e.RowIndex).Cells("col_filename").Value.ToString) & ".html"
        WebBrowser1.Navigate(fullName)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If (folder1.ShowDialog() = DialogResult.OK) Then
            outputPath.Text = folder1.SelectedPath
        End If
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        showGallery()
    End Sub

    Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Button2.Left = Me.Width - Button2.Width - 20
    End Sub

    Private Sub TabPage6_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TabPage6.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label2_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Label2.DragDrop
        Dim files() As String = e.Data.GetData(DataFormats.FileDrop)
        For Each path In files
            pdf1.src = path
        Next
        Label2.Visible = False
    End Sub

    Private Sub Label2_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Label2.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub PictureBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseDown
        If e.Button = MouseButtons.Left Then ' draw a filled circle if left mouse is down  
            
            mousePath.StartFigure()    ' The L mouse is down so we need to start a new line in mousePath
        End If
    End Sub

    Private Sub PictureBox2_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseMove
        If e.Button = MouseButtons.Left Then ' draw a filled circle if left mouse is down  

            mousePath.AddLine(e.X, e.Y, e.X, e.Y)    'Add mouse coordiantes to mousePath
           
            PictureBox2.Invalidate() 'Repaint the PictureBox using the PictureBox1 Paint event
        End If


    End Sub

    Private Sub PictureBox2_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles PictureBox2.Paint

        Try

            myAlpha = 255
            Dim CurrentPen = New Pen(Color.FromArgb(myAlpha, myUserColor), myPenWidth) 'Set up the pen
           
            e.Graphics.DrawPath(CurrentPen, mousePath)  'draw the path! :)
            DrawingGraphics.DrawPath(CurrentPen, mousePath)
            e.Graphics.DrawImage(DrawingImg, PictureBox2.Width, PictureBox2.Height)

        Catch

        End Try
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub brush_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles brush.Click
        myUserColor = (System.Drawing.Color.Black)
    End Sub

    Private Sub eraser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles eraser.Click
        myUserColor = (System.Drawing.Color.White)
    End Sub


    Private Sub brushSize_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles brushSize.Scroll
        myPenWidth = brushSize.Value
    End Sub

    Private Sub PictureBox2_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseUp

    End Sub

    Private Sub clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clear.Click

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        importMode = TabControl1.SelectedIndex


    End Sub
End Class

Public Class Base64Codec
    ''Function to Get Image from Base64 Encoded String
    Public Function GetImageFromBase64(ByVal Base64String) As Bitmap
        Dim fileBytes As Byte()
        Dim streamImage As Bitmap
        Try
            If (String.Empty <> Base64String) Then ''Checking The Base64 string validity

                fileBytes = Convert.FromBase64String(Base64String) ''Convert Base64 to Byte Array

                Using ms As New MemoryStream(fileBytes) ''Using Memory stream to save image

                    streamImage = Image.FromStream(ms) ''Converting image from Memory stream

                    If Not IsNothing(streamImage) Then

                        ''Save image to temp path
                        streamImage.Save(Path.GetTempPath(), System.Drawing.Imaging.ImageFormat.Jpeg)

                    End If

                End Using

            End If

        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")

        End Try

        Return streamImage

    End Function

    ''Convert the Image from Input to Base64 Encoded String
    Public Function ConvertImageToBase64(ByVal ImageInput As Image) As String

        Dim Base64Op As String = String.Empty

        Try

            Dim ms As MemoryStream = New MemoryStream()

            ImageInput.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg) ''Temp saving the stream image

            Base64Op = Convert.ToBase64String(ms.ToArray())
            ms.Close()
        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")

        End Try

        Return Base64Op

    End Function

End Class
